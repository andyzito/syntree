Use Case #5: Uploading a Tree
=============================

Actors
------
- User (User)
- Syntree app (App)

Preconditions
-------------
- User has opened the application

Steps
-----
#. User: clicks "Upload" button in toolbar

#. App: displays standard file dialog with file type defaulted to '.tree'

#. User: selects desired '.tree' file

#. User: clicks "Open" or equivalent in standard file dialog

#. App: loads and displays Tree from file